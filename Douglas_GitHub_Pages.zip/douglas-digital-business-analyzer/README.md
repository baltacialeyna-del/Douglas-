# Douglas Digital Business Analyzer

Analyse-Tool zur digitalen Transformation des Geschäftsmodells der Douglas Group
(DHBW Karlsruhe, Modul „Digitale Transformation – Geschäftsmodelle“).

Die Anwendung ist eine einzelne, eigenständige Datei (`index.html`) ohne Server,
ohne Build-Schritt und ohne Abhängigkeit von Claude. Alle Daten sind eingebettet; Bearbeitungen speichert der Browser.
Nur die Schriftarten werden online von Google Fonts geladen.

## Veröffentlichen mit GitHub Pages

1. Auf github.com ein neues Repository anlegen (z. B. `douglas-analyzer`, öffentlich).
2. „Add file“ → „Upload files“ → `index.html`, `.nojekyll` und `README.md` hochladen → „Commit changes“.
3. Im Repository „Settings“ → „Pages“ öffnen.
4. Unter „Build and deployment“: Source „Deploy from a branch“, Branch `main`, Ordner `/ (root)` → „Save“.
5. Nach ein bis zwei Minuten ist die Seite erreichbar unter
   `https://<benutzername>.github.io/<repository-name>/`

## Hinweise

- Navigation, Diagramme, Regler der Bewertungsmatrix, Reiter, Aufklapper und Quellen-Knöpfe funktionieren ohne Internetzugang zu Claude.
- Bearbeiten ist auf der Website möglich (Steckbrief, Canvas, Reifegrad, Ideen-Bewertung). Änderungen werden nur im Browser der jeweiligen Person gespeichert und verändern die veröffentlichte Seite nicht.
- Die Leiste unten rechts bietet „Stand exportieren“ (JSON-Datei), „Importieren“ und „Zurücksetzen“ auf den Originalstand vom 09.11.2026.
- Gemeinsames Speichern für alle gibt es nur in der Claude-Version des Tools.
- Analyse auf Basis öffentlicher Quellen, kein Angebot der Douglas Group.
